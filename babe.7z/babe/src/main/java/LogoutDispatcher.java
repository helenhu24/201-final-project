package main.java;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@SpringBootApplication
@RestController

/**
 * Servlet implementation class LogoutDispatcher
 */
@WebServlet("/LogoutDispatcher") // denotes this as a servlet; referenced Piazza for this
public class LogoutDispatcher extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        // TODO Remove userID cookie
    	// I referenced https://www.javatpoint.com/cookies-in-servlet for how to utilize cookies
    	response.setContentType("text/html");
    	Cookie c = new Cookie("userName", "test");
    	Cookie c2 = new Cookie("loginID", "yaya");
    	c.setMaxAge(0);
    	c2.setMaxAge(0);
    	response.addCookie(c);
    	response.addCookie(c2);
    	response.sendRedirect("index.jsp");

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        doGet(request, response);
    }

}
